# Pinecone Coffee - 12-week sales report

Which drink brings in the most money? This small project answers that
question with 12 weeks of daily sales (84 days x 6 drinks).

## Files

| File | What it is |
|---|---|
| `data/sales.csv` | one row per drink per day: date, drink, cups, price |
| `analysis.py` | prints cups and revenue by drink |
| `report.ipynb` | the same analysis, plus a bar chart |
| `requirements.txt` | the packages this project needs |

## How to run it

1. Clone this repository and open the **folder** in VS Code (File > Open Folder).
2. Install the packages in the terminal: `python -m pip install -r requirements.txt`
3. Run `analysis.py`, or open `report.ipynb` and click **Run All**.
