# analysis.py - Which drink brings in the most money?
import pandas as pd

sales = pd.read_csv("data/sales.csv")
sales["revenue"] = sales["cups"] * sales["price"]

summary = sales.groupby("drink")[["cups", "revenue"]].sum()
summary = summary.sort_values("revenue", ascending=False)

print("Pinecone Coffee - sales report (12 weeks)")
print(summary)
print()
print("Top drink by revenue:", summary.index[0])
